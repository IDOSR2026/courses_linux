# IDOSR_2026 — site de cours

```
index.html        page + contenu des cours
css/style.css     styles
js/hash.js        hachage des mots de passe
js/config.js      liste des cours, réglages, données de secours
js/storage.js     données partagées (users.json) + copie locale (localStorage)
js/app.js         connexion, panneau Admin, panneau Utilisateur
data/users.json   utilisateurs / permissions / compte admin (mots de passe HACHÉS)
```

Comptes de départ : `admin / maaroufi2026` · `user1 / user123` · `user2 / user456`
→ changez-les dès la première connexion (panneau Admin).

## Publier une modification pour TOUS les navigateurs
1. Connectez-vous en admin, faites vos changements, cliquez **💾 Tout enregistrer**.
2. Cliquez **⬇ Exporter users.json**.
3. Sur GitHub : ouvrez `data/` → **Add file → Upload files** → déposez le nouveau `users.json`
   (même nom) → **Commit changes**.
4. Attendez 1 à 10 minutes (cache GitHub Pages), puis rechargez la page.

## Tester en local
Double-clic sur `index.html` fonctionne (données de secours), mais pour lire `data/users.json`
lancez un petit serveur :  `python3 -m http.server`  puis ouvrez http://localhost:8000
